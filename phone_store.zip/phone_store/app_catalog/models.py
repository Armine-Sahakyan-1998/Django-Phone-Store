from django.db import models
class Phone(models.Model):
    brand = models.CharField(max_length=50)
    model = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to='phone_images/')


    def __str__(self):
        return f"{self.brand} {self.model}"

# Create your models here.
