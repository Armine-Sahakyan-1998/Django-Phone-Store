from django.shortcuts import render, get_object_or_404

from .models import Phone

def phone_list(request):
    phones = Phone.objects.all()
    return render(request, 'app_catalog/phone_list.html',
                  {"phones": phones})

# Create your views here.
def phone_detail(request, pk):
    # Եթե ID-ն գտնվի, կվերցնի տվյալները, եթե ոչ՝ կցուցադրի 404 սխալի էջը
    phone = get_object_or_404(Phone, pk=pk)
    return render(request, 'app_catalog/phone_detail.html', {"phone": phone})