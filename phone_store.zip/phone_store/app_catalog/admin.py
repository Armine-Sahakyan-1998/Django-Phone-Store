from django.contrib import admin

from .models import Phone

@admin.register(Phone)
class PhoneAdmin(admin.ModelAdmin):
    list_display = ("brand", "model", "price")
    search_fields = ("brand", "model")

 